### Hexlet tests and linter status:
[![Actions Status](https://github.com/AlexTeneneva/python-project-49/actions/workflows/hexlet-check.yml/badge.svg)](https://github.com/AlexTeneneva/python-project-49/actions)

[![Maintainability](https://api.codeclimate.com/v1/badges/2e59aa1a90e835d1182b/maintainability)](https://codeclimate.com/github/AlexTeneneva/python-project-49/maintainability)

brain-even
[![asciicast](https://asciinema.org/a/hMf2UfQUzIpKF6YdNs1z4R51N.svg)](https://asciinema.org/a/hMf2UfQUzIpKF6YdNs1z4R51N)

brain-calc
[![asciicast](https://asciinema.org/a/O9hXBnNLzBqPvhYeFh5Ciz14k.svg)](https://asciinema.org/a/O9hXBnNLzBqPvhYeFh5Ciz14k)

brain-gcd:
[![asciicast](https://asciinema.org/a/Y4sRuljJEhHSf1pVi3TdEBfDN.svg)](https://asciinema.org/a/Y4sRuljJEhHSf1pVi3TdEBfDN)

brain-progression: 
[![asciicast](https://asciinema.org/a/hgxgZZ3KWkp2z7u84KE6FWf8e.svg)](https://asciinema.org/a/hgxgZZ3KWkp2z7u84KE6FWf8e)


brain-prime:
[![asciicast](https://asciinema.org/a/48J3C68SRfFOGPPTZvxXdTU1d.svg)](https://asciinema.org/a/48J3C68SRfFOGPPTZvxXdTU1d)