### Hexlet tests and linter status:
[![Actions Status](https://github.com/AlexTeneneva/python-project-49/actions/workflows/hexlet-check.yml/badge.svg)](https://github.com/AlexTeneneva/python-project-49/actions)

[![Maintainability](https://api.codeclimate.com/v1/badges/2e59aa1a90e835d1182b/maintainability)](https://codeclimate.com/github/AlexTeneneva/python-project-49/maintainability)

