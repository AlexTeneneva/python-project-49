#!/usr/bin/env python3

import random
from brain_games.games.even import main

if __name__ == '__main__':
    main()

