#!/usr/bin/env python3

import random
from brain_games import cli
from brain_games import even


def main ():
    cli.welcome_user()
    even.even()

if __name__ == '__main__':
    main()

